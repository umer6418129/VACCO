<?php
$conn = mysqli_connect('localhost','root','','vaccination')or die('connection lost');
?>